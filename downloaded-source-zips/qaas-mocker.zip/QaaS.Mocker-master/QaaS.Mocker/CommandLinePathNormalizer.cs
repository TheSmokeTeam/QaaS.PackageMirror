namespace QaaS.Mocker;

/// <summary>
/// Rewrites CLI path arguments so configuration files, overlays, and template output resolve from
/// the caller's working directory instead of the process host directory.
/// </summary>
internal static class CommandLinePathNormalizer
{
    /// <summary>
    /// Normalizes path-bearing arguments and optionally appends the <c>--no-env</c> switch.
    /// </summary>
    public static string[] Normalize(
        IEnumerable<string> args,
        string callerWorkingDirectory,
        string fallbackInputWorkingDirectory,
        bool includeNoEnvFlag = false)
    {
        ArgumentNullException.ThrowIfNull(args);
        ArgumentException.ThrowIfNullOrWhiteSpace(callerWorkingDirectory);
        ArgumentException.ThrowIfNullOrWhiteSpace(fallbackInputWorkingDirectory);

        var normalizedArguments = RewriteRelativePaths(
            args.ToArray(),
            callerWorkingDirectory,
            fallbackInputWorkingDirectory);

        if (includeNoEnvFlag && normalizedArguments.All(argument =>
                !string.Equals(argument, "--no-env", StringComparison.OrdinalIgnoreCase)))
        {
            normalizedArguments.Add("--no-env");
        }

        return [.. normalizedArguments];
    }

    private static List<string> RewriteRelativePaths(
        IReadOnlyList<string> args,
        string callerWorkingDirectory,
        string fallbackInputWorkingDirectory)
    {
        var rewrittenArguments = new List<string>(args.Count + 1);
        var configurationFileResolved = false;

        for (var index = 0; index < args.Count; index++)
        {
            var argument = args[index];

            // The first positional token is always the command slot in the Runner-style CLI.
            // Preserve it as-is so unknown commands still fail as commands instead of being
            // rewritten into configuration-file paths.
            if (index == 0 && !IsOption(argument))
            {
                rewrittenArguments.Add(argument);
                continue;
            }

            if (TryRewriteSingleValueOption(
                    args,
                    ref index,
                    rewrittenArguments,
                    "--output-folder",
                    "-o",
                    value => ResolveOutputPath(value, callerWorkingDirectory)))
            {
                continue;
            }

            if (TryRewriteListOption(
                    args,
                    ref index,
                    rewrittenArguments,
                    "--overwrite-files",
                    "-w",
                    value => ResolveInputPath(value, callerWorkingDirectory, fallbackInputWorkingDirectory)))
            {
                continue;
            }

            if (TryRewriteListOption(
                    args,
                    ref index,
                    rewrittenArguments,
                    "--overwrite-folders",
                    "-f",
                    value => ResolveInputPath(value, callerWorkingDirectory, fallbackInputWorkingDirectory)))
            {
                continue;
            }

            if (TryRewriteListOption(
                    args,
                    ref index,
                    rewrittenArguments,
                    "--overwrite-arguments",
                    "-r",
                    static value => value))
            {
                continue;
            }

            if (!configurationFileResolved && !IsOption(argument))
            {
                // Only the first bare positional value is treated as the main configuration file.
                rewrittenArguments.Add(
                    ResolveInputPath(argument, callerWorkingDirectory, fallbackInputWorkingDirectory));
                configurationFileResolved = true;
                continue;
            }

            rewrittenArguments.Add(argument);
        }

        return rewrittenArguments;
    }

    private static bool TryRewriteSingleValueOption(
        IReadOnlyList<string> args,
        ref int index,
        ICollection<string> rewrittenArguments,
        string longName,
        string shortName,
        Func<string, string> transform)
    {
        var argument = args[index];
        if (IsOptionName(argument, longName, shortName))
        {
            rewrittenArguments.Add(argument);
            if (index + 1 < args.Count)
            {
                rewrittenArguments.Add(transform(args[index + 1]));
                index++;
            }

            return true;
        }

        if (!TrySplitOption(argument, longName, shortName, out var optionName, out var value))
            return false;

        rewrittenArguments.Add($"{optionName}={transform(value)}");
        return true;
    }

    private static bool TryRewriteListOption(
        IReadOnlyList<string> args,
        ref int index,
        ICollection<string> rewrittenArguments,
        string longName,
        string shortName,
        Func<string, string> transform)
    {
        var argument = args[index];
        if (IsOptionName(argument, longName, shortName))
        {
            rewrittenArguments.Add(argument);
            while (index + 1 < args.Count && !IsOption(args[index + 1]))
            {
                rewrittenArguments.Add(transform(args[index + 1]));
                index++;
            }

            return true;
        }

        if (!TrySplitOption(argument, longName, shortName, out var optionName, out var value))
            return false;

        rewrittenArguments.Add($"{optionName}={transform(value)}");
        return true;
    }

    private static bool TrySplitOption(
        string argument,
        string longName,
        string shortName,
        out string optionName,
        out string value)
    {
        var splitIndex = argument.IndexOf('=');
        if (splitIndex <= 0)
        {
            optionName = string.Empty;
            value = string.Empty;
            return false;
        }

        optionName = argument[..splitIndex];
        value = argument[(splitIndex + 1)..];
        return IsOptionName(optionName, longName, shortName);
    }

    private static bool IsOptionName(string argument, string longName, string shortName) =>
        string.Equals(argument, longName, StringComparison.OrdinalIgnoreCase) ||
        string.Equals(argument, shortName, StringComparison.OrdinalIgnoreCase);

    private static bool IsOption(string argument) => argument.StartsWith("-", StringComparison.Ordinal);

    private static string ResolveInputPath(
        string path,
        string callerWorkingDirectory,
        string fallbackInputWorkingDirectory)
    {
        if (Path.IsPathRooted(path))
            return path;

        var callerRelativePath = Path.GetFullPath(path, callerWorkingDirectory);
        if (PathExists(callerRelativePath))
            return callerRelativePath;

        var fallbackRelativePath = Path.GetFullPath(path, fallbackInputWorkingDirectory);
        return PathExists(fallbackRelativePath) ? fallbackRelativePath : callerRelativePath;
    }

    private static string ResolveOutputPath(string path, string callerWorkingDirectory) =>
        Path.IsPathRooted(path) ? path : Path.GetFullPath(path, callerWorkingDirectory);

    private static bool PathExists(string path) => File.Exists(path) || Directory.Exists(path);
}
