﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace QaaS.Common.Probes.ConfigurationObjects.Os;

/// <summary>
/// Connection settings required by probes that authenticate against an OpenShift cluster.
/// </summary>
public record Openshift
{
    [Required, Description("The openshift cluster api")]
    public string? Cluster { get; set; }

    [Required, Description("Username with access to the openshift namespace and application")]
    public string? Username { get; set; }

    [Required, Description("Password of the username with access to the openshift namespace and application")]
    public string? Password { get; set; }

    [Required, Description("The openshift namespace the application is at")]
    public string? Namespace { get; set; }

    [Description("Allow invalid TLS certificates when connecting to the OpenShift API. Defaults to true to preserve the historical OpenShift probe behavior for local and self-signed clusters unless callers explicitly opt into strict validation."),
     DefaultValue(true)]
    public bool AllowInvalidServerCertificates { get; set; } = true;
}
