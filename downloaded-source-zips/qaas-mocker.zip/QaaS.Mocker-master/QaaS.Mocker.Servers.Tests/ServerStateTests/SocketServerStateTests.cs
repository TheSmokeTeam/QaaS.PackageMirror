using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using System.Net.Sockets;
using System.Text;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using QaaS.Framework.SDK.ContextObjects;
using QaaS.Framework.SDK.ConfigurationObjects;
using QaaS.Framework.SDK.DataSourceObjects;
using QaaS.Framework.SDK.Hooks.Generator;
using QaaS.Framework.SDK.Hooks.Processor;
using QaaS.Framework.SDK.Session.DataObjects;
using QaaS.Framework.SDK.Session.MetaDataObjects;
using QaaS.Framework.SDK.Session.SessionDataObjects;
using QaaS.Mocker.Servers.ConfigurationObjects.SocketServerConfigs;
using QaaS.Mocker.Servers.Exceptions;
using QaaS.Mocker.Servers.ServerStates;
using QaaS.Mocker.Stubs.Stubs;

namespace QaaS.Mocker.Servers.Tests.ServerStateTests;

[TestFixture]
public class SocketServerStateTests
{
    [Test]
    public void Constructor_WithCollectAndBroadcastEndpoints_SetsBothInputOutputState()
    {
        var state = CreateState(
            [
                BuildEndpoint(7001, "CollectAction", SocketMethod.Collect),
                BuildEndpoint(7002, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")
            ]);

        Assert.That(state.InputOutputState, Is.EqualTo(QaaS.Framework.SDK.ConfigurationObjects.InputOutputState.BothInputOutput));
    }

    [Test]
    public void Constructor_WithCollectEndpoint_EnablesActionByDefault()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);

        Assert.That(state.IsEndpointPortActionEnabled(7001), Is.True);
    }

    [Test]
    public void Constructor_WithBroadcastEndpoint_DisablesActionByDefault()
    {
        var state = CreateState([BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")]);

        Assert.That(state.IsEndpointPortActionEnabled(7001), Is.False);
    }

    [Test]
    public void Constructor_WithOnlyBroadcastEndpoint_SetsOnlyOutputState()
    {
        var state = CreateState([BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")]);

        Assert.That(state.InputOutputState, Is.EqualTo(QaaS.Framework.SDK.ConfigurationObjects.InputOutputState.OnlyOutput));
    }

    [Test]
    public void Constructor_WithUnknownSocketMethod_ThrowsArgumentOutOfRangeException()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            CreateState([BuildEndpoint(7001, "UnknownAction", (SocketMethod)999)]));
    }

    [Test]
    public void Process_WithKnownCollectPort_StoresInputWhenCacheEnabled()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);
        var cache = state.GetCache();
        cache.EnableStorage = true;

        _ = state.Process(7001, [CreateRequest("payload")]).ToList();

        Assert.Multiple(() =>
        {
            Assert.That(cache.RetrieveFirstOrDefaultStringInput(), Is.Not.Null);
            Assert.That(cache.RetrieveFirstOrDefaultStringOutput(), Is.Null);
        });
    }

    [Test]
    public void Process_WithUnknownPort_DoesNotThrowAndReturnsOriginalData()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);
        var input = CreateRequest("payload");

        var result = state.Process(9999, [input]).Single();

        Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("payload"));
    }

    [Test]
    public void Process_WhenStubThrows_ReturnsOriginalPayload()
    {
        var state = CreateState(
            [BuildEndpoint(7001, "CollectAction", SocketMethod.Collect, transactionStubName: "BrokenStub")],
            ("BrokenStub", _ => throw new InvalidOperationException("boom")));

        var input = CreateRequest("payload");
        var result = state.Process(7001, [input]).Single();

        Assert.That(result, Is.SameAs(input));
    }

    [Test]
    public void ProcessBroadcast_WithMissingDataSource_ThrowsException()
    {
        var state = CreateState([BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "missing")]);

        var exception = Assert.Throws<Exception>(() => state.Process(7001).ToArray());

        Assert.That(exception!.Message, Does.Contain("DataSource"));
    }

    [Test]
    public async Task TriggerAction_WithExistingAction_EnablesTemporarily()
    {
        var state = CreateState([BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")]);

        Assert.That(state.IsEndpointPortActionEnabled(7001), Is.False);

        state.TriggerAction("BroadcastAction", 80);

        var becameEnabled = false;
        for (var i = 0; i < 20; i++)
        {
            if (state.IsEndpointPortActionEnabled(7001))
            {
                becameEnabled = true;
                break;
            }

            await Task.Delay(5);
        }

        var becameDisabled = false;
        for (var i = 0; i < 40; i++)
        {
            if (!state.IsEndpointPortActionEnabled(7001))
            {
                becameDisabled = true;
                break;
            }

            await Task.Delay(5);
        }

        Assert.Multiple(() =>
        {
            Assert.That(becameEnabled, Is.True);
            Assert.That(becameDisabled, Is.True);
        });
    }

    [Test]
    public void TriggerAction_WithUnknownAction_Throws()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);

        Assert.Throws<ActionDoesNotExistException>(() => state.TriggerAction("MissingAction", 100));
    }

    [Test]
    public void ChangeActionStub_WhenActionExists_ChangesRoutedStub()
    {
        var state = CreateState(
            [BuildEndpoint(7001, "CollectAction", SocketMethod.Collect, transactionStubName: "MainStub")],
            ("MainStub", _ => CreateRequest("main")),
            ("AltStub", _ => CreateRequest("alt")));

        state.ChangeActionStub("CollectAction", "AltStub");
        var result = state.Process(7001, [CreateRequest("input")]).Single();

        Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("alt"));
    }

    [Test]
    public void ChangeActionStub_WhenActionNameDiffersByCase_ChangesRoutedStub()
    {
        var state = CreateState(
            [BuildEndpoint(7001, "CollectAction", SocketMethod.Collect, transactionStubName: "MainStub")],
            ("MainStub", _ => CreateRequest("main")),
            ("AltStub", _ => CreateRequest("alt")));

        state.ChangeActionStub("collectaction", "AltStub");
        var result = state.Process(7001, [CreateRequest("input")]).Single();

        Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("alt"));
    }

    [Test]
    public void ChangeActionStub_WhenStubDoesNotExist_ThrowsStubNotLoadedException()
    {
        var state = CreateState(
            [BuildEndpoint(7001, "CollectAction", SocketMethod.Collect, transactionStubName: "MainStub")],
            ("MainStub", _ => CreateRequest("main")));

        Assert.Throws<StubNotLoadedException>(() => state.ChangeActionStub("CollectAction", "MissingStub"));
    }

    [Test]
    public void ChangeActionStub_WhenActionHasNoExistingStub_AssignsStubSuccessfully()
    {
        var state = CreateState(
            [BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)],
            ("MainStub", _ => CreateRequest("main")));

        state.ChangeActionStub("CollectAction", "MainStub");
        var result = state.Process(7001, [CreateRequest("input")]).Single();

        Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("main"));
    }

    [Test]
    public void Constructor_WithCaseInsensitiveStubName_ResolvesStub()
    {
        var endpoint = BuildEndpoint(7001, "CollectAction", SocketMethod.Collect, transactionStubName: "MAINSTUB");
        var state = CreateState([endpoint], ("mainstub", _ => CreateRequest("processed")));

        var result = state.Process(7001, [CreateRequest("input")]).Single();

        Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("processed"));
    }

    [Test]
    public void HasAction_WithCaseInsensitiveName_ReturnsTrue()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);

        Assert.That(state.HasAction("collectaction"), Is.True);
    }

    [Test]
    public void ProcessBroadcast_WithUnknownPort_ThrowsMissingDataSourceException()
    {
        var state = CreateState([BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")]);

        var exception = Assert.Throws<Exception>(() => state.Process(9999).ToArray());

        Assert.That(exception!.Message, Does.Contain("9999"));
    }

    [Test]
    public void ProcessBroadcast_WithConfiguredDataSource_ReturnsPayloadAndStoresOutput()
    {
        var stateWithDataSources = CreateStateWithDataSources(
            [BuildEndpoint(7001, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")],
            [
                CreateDataSource("ds1", CreateRequest("broadcast"))
            ]);
        var cache = stateWithDataSources.GetCache();
        cache.EnableStorage = true;

        var result = stateWithDataSources.Process(7001).Single();

        Assert.Multiple(() =>
        {
            Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("broadcast"));
            Assert.That(cache.RetrieveFirstOrDefaultStringOutput(), Is.Not.Null);
            Assert.That(cache.RetrieveFirstOrDefaultStringInput(), Is.Null);
        });
    }

    [Test]
    public void Process_WithUnknownPortAndCombinedState_StoresInputAndOutput()
    {
        var state = CreateState(
            [
                BuildEndpoint(7001, "CollectAction", SocketMethod.Collect),
                BuildEndpoint(7002, "BroadcastAction", SocketMethod.Broadcast, dataSourceName: "ds1")
            ]);
        var cache = state.GetCache();
        cache.EnableStorage = true;

        var result = state.Process(9999, [CreateRequest("payload")]).Single();

        Assert.Multiple(() =>
        {
            Assert.That(state.InputOutputState, Is.EqualTo(InputOutputState.BothInputOutput));
            Assert.That(Encoding.UTF8.GetString((byte[])result.Body!), Is.EqualTo("payload"));
            Assert.That(cache.RetrieveFirstOrDefaultStringInput(), Is.Not.Null);
            Assert.That(cache.RetrieveFirstOrDefaultStringOutput(), Is.Not.Null);
        });
    }

    [Test]
    public void ChangeActionStub_WhenActionDoesNotExist_ThrowsActionDoesNotExistException()
    {
        var state = CreateState([BuildEndpoint(7001, "CollectAction", SocketMethod.Collect)]);

        Assert.Throws<ActionDoesNotExistException>(() => state.ChangeActionStub("MissingAction", "StubA"));
    }

    private static SocketServerState CreateState(
        SocketEndpointConfig[] endpoints,
        params (string Name, Func<Data<object>, Data<object>> Processor)[] stubs)
    {
        return CreateStateWithDataSources(endpoints, [], stubs);
    }

    private static SocketServerState CreateStateWithDataSources(
        SocketEndpointConfig[] endpoints,
        DataSource[] dataSources,
        params (string Name, Func<Data<object>, Data<object>> Processor)[] stubs)
    {
        var mappedStubs = stubs.Length == 0
            ? ImmutableList<TransactionStub>.Empty
            : stubs.Select(tuple => CreateStub(tuple.Name, tuple.Processor)).ToImmutableList();

        return new SocketServerState(
            Globals.Logger,
            dataSources.ToImmutableList(),
            mappedStubs,
            endpoints);
    }

    private static SocketEndpointConfig BuildEndpoint(
        int port,
        string actionName,
        SocketMethod method,
        string? dataSourceName = null,
        string? transactionStubName = null)
    {
        return new SocketEndpointConfig
        {
            Port = port,
            ProtocolType = ProtocolType.Tcp,
            TimeoutMs = 100,
            Action = new SocketActionConfig
            {
                Name = actionName,
                Method = method,
                DataSourceName = dataSourceName,
                TransactionStubName = transactionStubName
            }
        };
    }

    private static TransactionStub CreateStub(string name, Func<Data<object>, Data<object>> process)
    {
        return new TransactionStub
        {
            Name = name,
            Processor = new DelegateProcessor(process),
            DataSourceList = ImmutableList<DataSource>.Empty
        };
    }

    private static Data<object> CreateRequest(string payload)
    {
        return new Data<object>
        {
            Body = Encoding.UTF8.GetBytes(payload),
            MetaData = new MetaData()
        };
    }

    private static DataSource CreateDataSource(string name, params Data<object>[] data)
    {
        return new DataSource
        {
            Name = name,
            DataSourceList = ImmutableList<DataSource>.Empty,
            Generator = new DelegateGenerator(data)
        };
    }

    private sealed class DelegateProcessor(Func<Data<object>, Data<object>> process) : ITransactionProcessor
    {
        public Context Context { get; set; } = null!;
        public List<ValidationResult>? LoadAndValidateConfiguration(IConfiguration configuration) => [];
        public Data<object> Process(IImmutableList<DataSource> dataSourceList, Data<object> requestData) => process(requestData);
    }

    private sealed class DelegateGenerator(IEnumerable<Data<object>> generatedData) : IGenerator
    {
        public Context Context { get; set; } = null!;

        public List<ValidationResult>? LoadAndValidateConfiguration(IConfiguration configuration) => [];

        public IEnumerable<Data<object>> Generate(
            IImmutableList<SessionData> sessionDataList,
            IImmutableList<DataSource> dataSourceList)
        {
            return generatedData;
        }
    }
}
