﻿using Amazon.S3;
using Microsoft.Extensions.Logging;

namespace QaaS.Framework.Protocols.Extentions;

/// <summary>
/// Extensions to the available operations on s3
/// </summary>
public static class S3Extentions
{
    /// <summary>
    /// Runs any s3 operation with a retry mechanism that handles the too many requests exception 
    /// </summary>
    /// <param name="s3OperationWithParameters"> A function that performs an s3 operation and returns
    /// the result of the operation</param>
    /// <param name="operationDescription"> The description of the operation,
    /// used for a log incase the operation does need a retry</param>
    /// <param name="maxRetryCount"> The maximum amount of retries when not successful,
    /// if no value is given there is no maximum amount and it can retry forever </param>
    /// <param name="logger"> The logger to log with </param>
    /// <typeparam name="T"> The return type of the given function </typeparam>
    /// <returns> The return value the given function returns </returns>
    public static T RunS3OperationWithRetryMechanism<T>(Func<T> s3OperationWithParameters,
        string operationDescription, int? maxRetryCount = null, ILogger? logger = null)
    {
        var retryCount = 0;
        while (true)
        {
            try
            {
                return s3OperationWithParameters.Invoke();
            }
            catch (AmazonS3Exception ex) when (ex.ErrorCode == "TooManyRequests" &&
                                               (!maxRetryCount.HasValue || retryCount < maxRetryCount.Value))
            {
                // Retry only the throttling case; all other S3 failures should bubble immediately so
                // callers do not mask authentication, missing bucket, or transport problems as retries.
                retryCount++;
                logger?.LogWarning(ex,
                    "S3 returned TooManyRequests while executing {OperationDescription}. Retry {RetryAttempt}{RetryLimit}.",
                    operationDescription,
                    retryCount,
                    maxRetryCount.HasValue ? $"/{maxRetryCount.Value}" : "/unbounded");
            }
            catch (AmazonS3Exception ex)
            {
                logger?.LogError(ex,
                    "S3 operation {OperationDescription} failed after {RetryCount} retries.",
                    operationDescription,
                    retryCount);
                throw;
            }
        }
    }
}
