using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using QaaS.Framework.Policies;
using QaaS.Framework.Protocols.Protocols;
using QaaS.Framework.SDK.ContextObjects;
using QaaS.Framework.SDK.DataSourceObjects;
using QaaS.Framework.SDK.Hooks.Generator;
using QaaS.Framework.SDK.Session;
using QaaS.Framework.SDK.Session.DataObjects;
using QaaS.Framework.SDK.Session.SessionDataObjects;
using QaaS.Framework.Serialization;
using QaaS.Runner.Sessions.Tests.Actions.Utils;
using Serilog;
using Serilog.Events;
using Serilog.Extensions.Logging;

namespace QaaS.Runner.Sessions.Tests.Actions.Transactions;

[TestFixture]
public class TransactionTests
{
    private const int DefaultTestMessagesPerSecond = 100_000;
    private static Mock<ITransactor> _transactor = null!;
    private static List<Data<object>> _infoSent = null!;

    [Test,
     TestCaseSource(typeof(TestResourceDataSources),
         nameof(TestResourceDataSources.ValidDataSourceNamesAndAppropriateFilters))]
    public void
        TestTransactAndInitializeIterableSerializableSaveIterator_ReceivesValidDataSourceNamesAndAppropriateFiltersAndLoopPolicy_SendsTheProperDataToTheSenderObject(
            List<string> names,
            List<string> patterns,
            List<DataSource> dataSources,
            List<Data<object>> expectedData)
    {
        // Arrange
        var amountOfDataToSend = expectedData.Count * 2;
        var transactor = CreationalFunctions.CreateTransactorWithLoop(
            ref _transactor!,
            "test data",
            ref _infoSent,
            patterns.ToArray(),
            names.ToArray(), 
            amountOfDataToSend);

        // Act
        transactor.InitializeIterableSerializableSaveIterator([], dataSources);
        transactor.Act();

        // Assert
        var orderedExpectedData = expectedData.SelectMany(d => new[] { d.Body, d.Body }).Order();
        var orderedReceivedData = _infoSent.Select(d => d.Body).Order();
        CollectionAssert.AreEqual(orderedExpectedData, orderedReceivedData);
    }

    private static Sessions.Actions.Transactions.Transaction InitTransactorWithIterations(
        string[]? dsPatterns,
        string[]? dsNames,
        int numberOfIterations,
        string dataToGet,
        int msgPerSec = DefaultTestMessagesPerSecond)
    {
        _infoSent = CreationalFunctions.InitTransactor(ref _transactor!, dataToGet);

        return new Sessions.Actions.Transactions.Transaction(
            "TestPub", _transactor!.Object, 0,
            new DataFilter() { Body = true, Timestamp = true, MetaData = false },
            new DataFilter() { Body = true, Timestamp = true, MetaData = false },
            new LoadBalancePolicy(msgPerSec, 1000),
            false, numberOfIterations, 0,
            null,
            null,
            null,
            dsPatterns, dsNames,
            new SerilogLoggerFactory(new LoggerConfiguration().MinimumLevel
                .Is(LogEventLevel.Information).WriteTo
                .Console().CreateLogger()).CreateLogger("DefaultLogger"));
    }

    [Test,
     TestCaseSource(typeof(TestResourceDataSources),
         nameof(TestResourceDataSources.ValidDataSourceNamesAndAppropriateFilters))]
    public void
        TestTransact_ReceivesValidDataSourceNamesAndAppropriateFiltersAndIterationsPolicy_SendsTheProperDataToTheSenderObject(
            List<string> names,
            List<string> patterns,
            List<DataSource> dataSources,
            List<Data<object>> expectedData)
    {
        // Arrange
        const int iterationNumber = 2;
        var transactor = InitTransactorWithIterations(patterns.ToArray(), names.ToArray(), iterationNumber, "test data");

        // Act
        transactor.InitializeIterableSerializableSaveIterator([], dataSources);
        transactor.Act();

        // Assert
        _transactor!.Verify(t => t.Transact(It.IsAny<Data<object>>()),
            Times.Exactly(expectedData.Count * iterationNumber));
    }

    [Test,
     TestCaseSource(typeof(TestResourceDataSources),
         nameof(TestResourceDataSources.ValidDataSourceNamesAndAppropriateFilters))]
    public void TestExportRunningCommunicationData_ReceivesRcdToExport_ExportTheGivenDataToTheRcd(
        List<string> names,
        List<string> patterns,
        List<DataSource> dataSources,
        List<Data<object>> expectedData)
    {
        // Arrange
        const string sessionName = "test session";
        var context = CreationalFunctions.CreateContext(sessionName, dataSources);
        var transactor = InitTransactorWithIterations(
            patterns.ToArray(),
            names.ToArray(),
            1, 
            "test data");

        // Act
        transactor.ExportRunningCommunicationData(context, sessionName);
        transactor.InitializeIterableSerializableSaveIterator([], dataSources);
        transactor.Act();

        // Arrange
        var expectedSentData = expectedData.Select(d => d.Body).Order().ToList();
        var expectedReceivedData = Enumerable.Repeat("test data", expectedData.Count).ToList();
        var receivedData =
            context.InternalRunningSessions.RunningSessionsDict[sessionName].Outputs![0].Data.Select(d => d!.Body)
                .Order().ToList();
        var sentData =
            context.InternalRunningSessions.RunningSessionsDict[sessionName].Inputs![0].Data.Select(d => d!.Body)
                .Order().ToList();
        CollectionAssert.AreEqual(expectedReceivedData, receivedData);
        CollectionAssert.AreEqual(expectedSentData, sentData);
    }

    [Test]
    public void TestExportRunningCommunicationData_PreservesTransactionMetadataOnExportedOutputs()
    {
        const string sessionName = "test session";
        var context = CreationalFunctions.CreateContext(sessionName, []);
        var transaction = InitTransactorWithIterations([], [], 1, "test data");

        transaction.ExportRunningCommunicationData(context, sessionName);

        var inputRcd = context.InternalRunningSessions.RunningSessionsDict[sessionName].Inputs![0];
        var outputRcd = context.InternalRunningSessions.RunningSessionsDict[sessionName].Outputs![0];

        Assert.That(inputRcd.Name, Is.EqualTo("TestPub"));
        Assert.That(outputRcd.Name, Is.EqualTo("TestPub"));
        Assert.That(outputRcd.SerializationType, Is.EqualTo(transaction.GetType()
            .GetMethod("GetOutputCommunicationSerializationType", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)!
            .Invoke(transaction, null)));
    }

    [Test]
    public void Act_WithBinaryOutputDeserializerAndNoSpecificType_DeserializesToOriginalPayloadType()
    {
        var payload = new BinaryPayload { Value = "transaction-output" };
        var serializer = SerializerFactory.BuildSerializer(SerializationType.Binary)!;
        var transactor = new Mock<ITransactor>();
        transactor.Setup(instance => instance.Transact(It.IsAny<Data<object>>()))
            .Returns(new Tuple<DetailedData<object>, DetailedData<object>?>(
                new DetailedData<object> { Body = "request" },
                new DetailedData<object> { Body = serializer.Serialize(payload) }));
        var transaction = new Sessions.Actions.Transactions.Transaction(
            "BinaryTransaction",
            transactor.Object,
            0,
            new DataFilter { Body = true, Timestamp = true, MetaData = true },
            new DataFilter { Body = true, Timestamp = true, MetaData = true },
            null,
            false,
            1,
            0,
            null,
            SerializationType.Binary,
            null,
            null,
            ["source-a"],
            Globals.Logger);
        var dataSource = new DataSource
        {
            Name = "source-a",
            DataSourceList = ImmutableList<DataSource>.Empty,
            Generator = new SingleItemGenerator()
        };

        transaction.InitializeIterableSerializableSaveIterator([], [dataSource]);
        var actData = transaction.Act();

        var body = actData.Output!.Single()!.Body;
        Assert.Multiple(() =>
        {
            Assert.That(body, Is.TypeOf<BinaryPayload>());
            Assert.That(((BinaryPayload)body!).Value, Is.EqualTo(payload.Value));
        });
    }

    [Serializable]
    private sealed class BinaryPayload
    {
        public string Value { get; set; } = string.Empty;
    }

    private sealed class SingleItemGenerator : IGenerator
    {
        public Context Context { get; set; } = null!;

        public List<ValidationResult>? LoadAndValidateConfiguration(IConfiguration configuration) => [];

        public IEnumerable<Data<object>> Generate(IImmutableList<SessionData> sessionDataList,
            IImmutableList<DataSource> dataSourceList)
        {
            return [new Data<object> { Body = "request" }];
        }
    }
}
